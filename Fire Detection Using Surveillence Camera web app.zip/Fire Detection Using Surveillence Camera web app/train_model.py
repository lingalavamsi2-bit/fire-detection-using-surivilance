import tensorflow as tf
import numpy as np
import cv2
import os
from sklearn.model_selection import train_test_split

def create_fire_model():
    model = tf.keras.Sequential([
        tf.keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(64, 64, 3)),
        tf.keras.layers.MaxPooling2D(2, 2),
        tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
        tf.keras.layers.MaxPooling2D(2, 2),
        tf.keras.layers.Conv2D(128, (3, 3), activation='relu'),
        tf.keras.layers.MaxPooling2D(2, 2),
        tf.keras.layers.Flatten(),
        tf.keras.layers.Dense(128, activation='relu'),
        tf.keras.layers.Dropout(0.5),
        tf.keras.layers.Dense(1, activation='sigmoid')
    ])
    
    model.compile(
        optimizer='adam',
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    return model

def generate_sample_data():
    # Generate synthetic training data for demo
    X = np.random.rand(1000, 64, 64, 3)
    y = np.random.randint(0, 2, 1000)
    
    # Add some fire-like patterns to positive samples
    for i in range(len(y)):
        if y[i] == 1:  # Fire samples
            # Add red/orange colors
            X[i, :, :, 0] = np.random.rand(64, 64) * 0.5 + 0.5  # More red
            X[i, :, :, 1] = np.random.rand(64, 64) * 0.3 + 0.2  # Some green
            X[i, :, :, 2] = np.random.rand(64, 64) * 0.2        # Less blue
    
    return X, y

def train_model():
    print("Generating sample data...")
    X, y = generate_sample_data()
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    print("Creating model...")
    model = create_fire_model()
    
    print("Training model...")
    history = model.fit(
        X_train, y_train,
        epochs=10,
        batch_size=32,
        validation_data=(X_test, y_test),
        verbose=1
    )
    
    print("Saving model...")
    os.makedirs('models', exist_ok=True)
    model.save('models/fire_model.h5')
    
    print(f"Model saved! Final accuracy: {history.history['val_accuracy'][-1]:.4f}")

if __name__ == "__main__":
    train_model()