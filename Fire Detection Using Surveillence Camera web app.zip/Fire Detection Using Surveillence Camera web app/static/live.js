let video, canvas, ctx, stream;
let isDetecting = false;

document.addEventListener('DOMContentLoaded', function() {
    video = document.getElementById('video');
    canvas = document.getElementById('canvas');
    ctx = canvas.getContext('2d');
    
    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');
    const statusText = document.getElementById('statusText');
    const confidence = document.getElementById('confidence');
    
    startBtn.addEventListener('click', startCamera);
    stopBtn.addEventListener('click', stopCamera);
    
    async function startCamera() {
        try {
            stream = await navigator.mediaDevices.getUserMedia({ 
                video: { width: 640, height: 480 } 
            });
            video.srcObject = stream;
            
            startBtn.disabled = true;
            stopBtn.disabled = false;
            statusText.textContent = 'Camera Active';
            
            // Start detection loop
            isDetecting = true;
            detectFire();
            
        } catch (err) {
            console.error('Error accessing camera:', err);
            statusText.textContent = 'Camera Error';
        }
    }
    
    function stopCamera() {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
        
        startBtn.disabled = false;
        stopBtn.disabled = true;
        statusText.textContent = 'Camera Stopped';
        isDetecting = false;
    }
    
    function detectFire() {
        if (!isDetecting) return;
        
        // Capture frame from video
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0);
        
        // Convert to base64 for API call
        const imageData = canvas.toDataURL('image/jpeg', 0.8);
        
        // Simulate fire detection (replace with actual API call)
        const mockConfidence = Math.random() * 0.3; // Low random confidence
        confidence.textContent = `${(mockConfidence * 100).toFixed(1)}%`;
        
        if (mockConfidence > 0.25) {
            statusText.textContent = '🚨 FIRE DETECTED!';
            statusText.style.color = 'red';
            // Trigger alert
            alert('FIRE DETECTED! Please check the area immediately.');
        } else {
            statusText.textContent = 'Monitoring...';
            statusText.style.color = 'green';
        }
        
        // Continue detection
        setTimeout(detectFire, 1000); // Check every second
    }
});