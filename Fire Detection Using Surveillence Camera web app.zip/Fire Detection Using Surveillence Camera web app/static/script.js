document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('video');
    const label = fileInput.nextElementSibling;
    
    fileInput.addEventListener('change', function() {
        if (this.files && this.files.length > 0) {
            label.textContent = `Selected: ${this.files[0].name}`;
            label.style.borderColor = '#667eea';
            label.style.background = '#f8f9ff';
        }
    });
    
    // Form validation
    const form = document.querySelector('form');
    form.addEventListener('submit', function(e) {
        if (!fileInput.files || fileInput.files.length === 0) {
            e.preventDefault();
            alert('Please select a video file first.');
            return false;
        }
        
        // Show loading state
        const submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.textContent = 'Analyzing...';
        submitBtn.disabled = true;
    });
});