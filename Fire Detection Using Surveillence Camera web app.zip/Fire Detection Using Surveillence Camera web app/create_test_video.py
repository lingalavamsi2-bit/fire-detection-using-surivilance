import cv2
import numpy as np
import os

def create_test_video():
    # Create test video with fire-like colors
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter('uploads/test_fire.mp4', fourcc, 20.0, (640, 480))
    
    for i in range(100):  # 5 second video at 20fps
        # Create frame with fire-like colors (red/orange)
        frame = np.zeros((480, 640, 3), dtype=np.uint8)
        
        # Add random fire-like patterns
        for _ in range(50):
            x = np.random.randint(0, 640)
            y = np.random.randint(200, 480)
            cv2.circle(frame, (x, y), np.random.randint(10, 30), 
                      (0, np.random.randint(100, 255), np.random.randint(200, 255)), -1)
        
        out.write(frame)
    
    out.release()
    print("Test video created: uploads/test_fire.mp4")

if __name__ == "__main__":
    os.makedirs('uploads', exist_ok=True)
    create_test_video()