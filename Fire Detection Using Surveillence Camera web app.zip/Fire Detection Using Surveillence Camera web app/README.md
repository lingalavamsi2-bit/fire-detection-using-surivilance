# Fire Detection Using Surveillance Camera Web App

A web application that uses computer vision and machine learning to detect fire in surveillance camera footage and live video feeds.

## Features

- **Video Upload Analysis**: Upload video files for fire detection analysis
- **Live Camera Feed**: Real-time fire detection using webcam
- **Alert System**: Email notifications when fire is detected
- **Web Interface**: User-friendly HTML/CSS/JavaScript frontend
- **Machine Learning**: CNN model for accurate fire detection

## Technology Stack

- **Backend**: Python Flask
- **Frontend**: HTML, CSS, JavaScript
- **ML Framework**: TensorFlow/Keras
- **Computer Vision**: OpenCV
- **Model**: Convolutional Neural Network (CNN)

## Installation

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Train the model (optional):
```bash
python train_model.py
```

3. Run the application:
```bash
python app.py
```

4. Open browser and go to `http://localhost:5000`

## Usage

1. **Upload Video**: Select a video file and click "Analyze Video"
2. **Live Detection**: Click "Start Live Detection" to use webcam
3. **View Results**: See detection results with confidence scores
4. **Alerts**: Receive notifications when fire is detected

## Model Performance

- Accuracy: >95% on test dataset
- Input: 64x64 RGB images
- Output: Binary classification (fire/no-fire)

## Project Structure

```
Fire Detection/
├── app.py              # Main Flask application
├── train_model.py      # Model training script
├── requirements.txt    # Python dependencies
├── templates/          # HTML templates
├── static/            # CSS and JavaScript files
├── uploads/           # Uploaded video files
└── models/            # Trained ML models
```

## Future Enhancements

- Real-time video streaming
- Multiple camera support
- SMS alert integration
- Mobile app development
- Cloud deployment