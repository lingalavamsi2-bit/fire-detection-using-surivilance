from flask import Flask, render_template, request, jsonify, flash, redirect, url_for
import cv2
import numpy as np
import os
from werkzeug.utils import secure_filename
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
import smtplib
from email.mime.text import MIMEText

app = Flask(__name__)
app.secret_key = 'fire_detection_secret_key'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Simple CNN model for fire detection
def create_fire_model():
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=(64, 64, 3)),
        MaxPooling2D(2, 2),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D(2, 2),
        Flatten(),
        Dense(128, activation='relu'),
        Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model

# Load or create model
try:
    model = tf.keras.models.load_model('models/fire_model.h5')
except:
    model = create_fire_model()

def preprocess_frame(frame):
    frame = cv2.resize(frame, (64, 64))
    frame = frame.astype('float32') / 255.0
    return np.expand_dims(frame, axis=0)

def detect_fire_in_frame(frame):
    processed_frame = preprocess_frame(frame)
    prediction = model.predict(processed_frame)[0][0]
    return prediction > 0.5, prediction

def send_alert_email(recipient_email):
    try:
        msg = MIMEText("FIRE DETECTED! Please check your surveillance camera immediately.")
        msg['Subject'] = 'FIRE ALERT - Immediate Action Required'
        msg['From'] = 'fire_detection@system.com'
        msg['To'] = recipient_email
        # Email sending logic would go here
        return True
    except:
        return False

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_video():
    if 'video' not in request.files:
        flash('No video file selected')
        return redirect(url_for('index'))
    
    file = request.files['video']
    if file.filename == '':
        flash('No video file selected')
        return redirect(url_for('index'))
    
    if file:
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Process video for fire detection
        cap = cv2.VideoCapture(filepath)
        fire_detected = False
        confidence_scores = []
        
        frame_count = 0
        while cap.read()[0] and frame_count < 100:  # Limit frames for demo
            ret, frame = cap.read()
            if ret:
                is_fire, confidence = detect_fire_in_frame(frame)
                confidence_scores.append(confidence)
                if is_fire:
                    fire_detected = True
                frame_count += 1
        
        cap.release()
        
        result = {
            'fire_detected': fire_detected,
            'avg_confidence': np.mean(confidence_scores) if confidence_scores else 0,
            'frames_processed': frame_count
        }
        
        if fire_detected:
            send_alert_email('user@example.com')
        
        return render_template('result.html', result=result, filename=filename)

@app.route('/live_feed')
def live_feed():
    return render_template('live_feed.html')

@app.route('/api/detect_frame', methods=['POST'])
def detect_frame():
    # For live camera feed detection
    data = request.get_json()
    # Process base64 image data from webcam
    return jsonify({'fire_detected': False, 'confidence': 0.0})

if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    os.makedirs('models', exist_ok=True)
    app.run(debug=True)